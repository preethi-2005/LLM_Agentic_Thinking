import os
import sys
import re
import json
from datetime import datetime
import google.generativeai as genai
from dotenv import load_dotenv

from calculator_tool import calculate
from translator_tool import translate

# Load environment
load_dotenv()
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
MODEL = "gemini-1.5-flash"

SYSTEM_RULES = (
    "You are a helpful tutor agent.\n"
    "You can use tools (calculator, translator).\n"
    "Always break queries into steps like Step 1, Step 2.\n"
    "If a query has multiple tasks, solve them step by step and combine results.\n"
)

# --- Helper functions ---
def is_math_query(q: str) -> bool:
    return any(word in q.lower() for word in [
        "add", "plus", "+", "multiply", "times", "*",
        "subtract", "minus", "divide", "/", "by"
    ]) or bool(re.search(r"\d+\s*[\+\-\/]\s\d+", q))

def split_math_steps(expression: str):
    """
    Extracts math operations like:
      - add 100 and 200
      - multiply 7 and 9
      - multiply 12 by 4
      - divide 10 by 2
      - 12 * 7
    """
    pattern = re.compile(
    r'(?:'  # non-capturing group for all math expressions
        r'add\s+\d+\.?\d*\s+(?:and|to)\s+\d+\.?\d*|'
        r'subtract\s+\d+\.?\d*\s+(?:and|from)\s+\d+\.?\d*|'
        r'multiply\s+\d+\.?\d*\s+(?:and|by)\s+\d+\.?\d*|'
        r'divide\s+\d+\.?\d*\s+(?:and|by)\s+\d+\.?\d*|'
        r'square\s+root\s+of\s+\d+\.?\d*|'
        r'squareroot\s+of\s+\d+\.?\d*|'
        r'sqrt\(\d+\.?\d*\)|'
        r'\d+\.?\d*\s*\^\s*\d+\.?\d*|'
        r'\d+\.?\d*\s*[\+\-\*/]\s*\d+\.?\d*'
    r')',
    re.IGNORECASE
)

    matches = pattern.findall(expression)
    return [m.strip() for m in matches if m.strip()]

def call_llm(question: str) -> str:
    model = genai.GenerativeModel(MODEL)
    response = model.generate_content(SYSTEM_RULES + "\nUser: " + question)
    return response.text

def save_log(question: str, answer: str):
    os.makedirs("level2", exist_ok=True)

    record = {
        "ts": datetime.utcnow().isoformat() + "Z",
        "question": question,
        "answer": answer
    }
    log_path = os.path.join("level3", "interactions_level3.log")
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")

# --- Agent executor ---
def agentic_executor(query: str) -> str:
    steps = []
    step_num = 1

    # Normalize "and then" -> "then" so we don't leave stray 'and'
    query = re.sub(r'\band\s+then\b', ' then ', query, flags=re.IGNORECASE)

    # Split by 'then' OR by 'and' only when 'and' is followed by a high-level verb.
    # This preserves "add 100 and 200" while still splitting "..., and multiply 2 and 5"
    split_pattern = r"\b(?:then|and(?=\s*(?:translate|multiply|add|subtract|divide|what|tell|who|where|how|when|is|are|does|do)))\b"
    raw_parts = [p.strip() for p in re.split(split_pattern, query, flags=re.IGNORECASE)]
    raw_parts = [p for p in raw_parts if p]  # drop empties

    # Safety: merge numeric-only fragments into previous part (in case something slipped)
    parts = []
    for p in raw_parts:
        if re.match(r'^[\s\W]\d+\.?\d[\s\W]*$', p) and parts:
            parts[-1] = parts[-1] + ' ' + p
        else:
            parts.append(p)

    for part in parts:
        # --- Translation ---
        if "translate" in part.lower():
            match = re.search(
                r"translate\s+'(.+?)'\s+(?:into|to)\s+(\w+)"
                r"|translate\s+'(.+?)'\s+from\s+(\w+)\s+to\s+(\w+)",
                part,
                re.IGNORECASE
            )

            if match:
                if match.group(1) and match.group(2):
                    text, target_lang = match.group(1), match.group(2)
                else:
                    # Case 2: ignore source_lang, only need target
                    text, target_lang = match.group(3), match.group(5)

                lang_codes = {
                    "german": "de",
                    "french": "fr",
                    "spanish": "es",
                    "italian": "it",
                    "japanese": "ja",
                    "hindi": "hi",
                    "telugu":"te",
                    "tamil":"ta",
                    "english":"en"
                }
                code = lang_codes.get(target_lang.lower(), "de")  # default German
                result = translate(text, target_lang=code)
                steps.append(f"Step {step_num}: Translate '{text}' → {result}")
                step_num += 1
            else:
                # fallback: if 'translate' present but regex didn't match, ask LLM
                result = call_llm(part)
                steps.append(f"Step {step_num}: LLM answer → {result}")
                step_num += 1

        # --- Math ---
        elif is_math_query(part):
            math_parts = split_math_steps(part)
            if not math_parts:
                # If we detected math intent but found no explicit pattern,
                # attempt to evaluate the whole part (e.g., "12 * 7" style)
                math_parts = [part]

            for m in math_parts:
                result = calculate(m)
                steps.append(f"Step {step_num}: Solve math → {result}")
                step_num += 1

        # --- Otherwise → LLM ---
        else:
            result = call_llm(part)
            steps.append(f"Step {step_num}: LLM answer → {result}")
            step_num += 1

    answer_text = "\n".join(steps)
    return "Answer:\n" + answer_text

# --- Main ---
def main():
    if len(sys.argv) < 2:
        print("Usage: python full_agent.py \"Your question here\"")
        sys.exit(1)

    query = sys.argv[1]
    answer = agentic_executor(query)
    print("\nAssistant:\n" + answer + "\n")
    save_log(query, answer)

if __name__== "__main__":
    main()