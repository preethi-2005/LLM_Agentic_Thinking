from googletrans import Translator

translator = Translator()

def translate(text: str, target_lang: str = "de") -> str:
    """
    Translate English text into any target language.
    
    Args:
        text (str): English text to translate.
        target_lang (str): Target language code (ISO 639-1), e.g. 'de', 'fr', 'es'.
        
    Returns:
        str: Translated text
    """
    try:
        result = translator.translate(text, src='en', dest=target_lang)
        return result.text
    except Exception as e:
        return f"❌ Translation Error: {e}"
