# Level 3 — HARD: Full Agentic AI with Multi-Step Tasks

A Python command-line assistant using **Gemini 1.5 Flash**, extended to handle **multi-step tasks** by orchestrating multiple tools (calculator, translator) and maintaining memory of steps.

---

## Features

- **Multi-step task handling:** Breaks queries into sequential steps.  
- **Tool integration:** Uses `calculator_tool.py` for math and `translator_tool.py` for translations.  
- **Step-by-step explanations:** Each task step is logged with a numbered format.  
- **Graceful handling of complex queries** like multi-step arithmetic, translations, and general knowledge questions.  
- **Logging:** All interactions are saved in `interactions_level3.log`.  

---

## Requirements

- Python 3.10+  
- [Gemini API Key](https://developers.generativeai.google/) stored in `.env` as `GEMINI_API_KEY`  
- Install dependencies:

```bash
pip install -r requirements.txt

## Dependencies include:

google-generativeai

googletrans

python-dotenv


## Usage
CLI Mode

Ask a multi-step question directly:

python Level3/full_agent.py "Translate 'Good Morning' into German and then multiply 5 and 6."


## Level 3 Rules

- Break queries into steps (Step 1, Step 2, …).
- Detect tasks and call the appropriate tool:
        1. Calculator for arithmetic.
        2. Translator for language translation.

- Use LLM for all other tasks or when a tool is not applicable.
- Combine results sequentially into a step-by-step answer.
- Logs are appended to level3/logs level3_interaction.log.



## Example Interactions

python Level3/full_agent.py "Add 20 and 30 and then multiply 2 and 5."

Assistant:
Answer:
Step 1: Solve math → 50.0
Step 2: Solve math → 10.0

###Example:
 python Level3/full_agent.py  "Translate 'Good Morning' into German and then multiply 5 and 6."

Assistant:
Answer:
Step 1: Translate 'Good Morning' → Guten Morgen
Step 2: Solve math → 30.0

