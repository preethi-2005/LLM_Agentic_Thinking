# Level 2 — MEDIUM: LLM + Basic Tool

A Python command-line assistant using **Gemini 1.5 Flash**, extended with a **calculator tool** for arithmetic operations.

---

## Features

- Detects **simple arithmetic questions** and uses a calculator tool (does not calculate directly in LLM).  
- Provides **step-by-step explanations** for normal queries.  
- Gracefully handles multi-step queries with a friendly message.  
- Logs all interactions in `interactions_level2.log`.  
- Supports **CLI mode** and **interactive mode**.  

---

## Requirements

- Python 3.10+  
- [Gemini API Key](https://developers.generativeai.google/) stored in `.env` as `GEMINI_API_KEY`  


- Install dependencies:

```bash
pip install -r requirements.txt

## Dependencies include:

- google-generativeai
- rich
- python-dotenv


## Usage
CLI Mode

Ask a question directly:

Level2/python chatbot_with_tool.py "What is 12 * 7?"


## Level 2 Rules

- Step-by-step explanations are provided for normal questions.

- Single-step arithmetic is detected and calculated using the calculator tool.

- Multi-step or combined queries are not handled yet (graceful failure).

- Logs are appended to interactions_level2.log.

###Example:
python level2/chatbot_with_tool.py  "What is 12 times 7?"                                 

Assistant:
========================================
Answer: 84

Steps:
Step 1: Use a calculator or perform the multiplication: 12 x 7 = 84

========================================



#Example 2:
python level2/chatbot_with_tool.py   "Multiply 9 and 8, and also tell me the capital of Japan."

Assistant:
========================================
I can’t do multi-step tasks yet (math + knowledge). Please ask one thing at a time.
========================================
