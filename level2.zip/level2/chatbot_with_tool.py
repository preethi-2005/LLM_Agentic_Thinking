import os
import sys
import re
import json
from datetime import datetime
import google.generativeai as genai
from dotenv import load_dotenv
from calculator_tool import calculate


# Load .env variables
load_dotenv()
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
MODEL = "gemini-1.5-flash"

SYSTEM_RULES = (
    "You are a helpful tutor.\n"
    "Always answer with two sections:\n"
    "Answer:\n"
    "Steps:\n"
    "For every knowledge question, break your explanation into short steps like Step 1, Step 2, Step 3 (no long paragraphs).\n"
    "For math-only questions, let the calculator tool handle them (you must not solve math).\n"
    "If a question mixes math + another request, politely refuse (say multi-step not supported yet)."
)

def detect_math_only(question: str) -> bool:
    q = question.lower()
    # Case 1: math symbols like "12 * 7"
    if re.search(r"\d+\s*[\+\-\*/]\s*\d+", q):
        return True
    # Case 2: math words like "add 5 and 6", "multiply 3 and 4"
    if re.search(r"(add|plus|sum|subtract|minus|multiply|times|divide|x)\s+\d+(\s*(and|,)?\s*\d+)+", q):
        return True
    return False

def detect_mixed_task(question: str) -> bool:
    q = question.lower()
    # Mixed task = math + secondary keywords
    secondary_keywords = r"(and also|tell me|capital|translate|fun fact|tallest)"
    if detect_math_only(q) and re.search(secondary_keywords, q):
        return True
    return False

def call_llm(question: str) -> str:
    model = genai.GenerativeModel(MODEL)
    response = model.generate_content(
        SYSTEM_RULES + "\nUser: " + question
    )
    return response.text

import os
import sys
import re
import json
from datetime import datetime
import google.generativeai as genai
from dotenv import load_dotenv
from calculator_tool import calculate


# Load .env variables
load_dotenv()
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
MODEL = "gemini-1.5-flash"

SYSTEM_RULES = (
    "You are a helpful tutor.\n"
    "Always answer with two sections:\n"
    "Answer:\n"
    "Steps:\n"
    "For every knowledge question, break your explanation into short steps like Step 1, Step 2, Step 3 (no long paragraphs).\n"
    "For math-only questions, let the calculator tool handle them (you must not solve math).\n"
    "If a question mixes math + another request, politely refuse (say multi-step not supported yet)."
)

def detect_math_only(question: str) -> bool:
    q = question.lower()
    # Case 1: math symbols like "12 * 7"
    if re.search(r"\d+\s*[\+\-\*/]\s*\d+", q):
        return True
    # Case 2: math words like "add 5 and 6", "multiply 3 and 4"
    if re.search(r"(add|plus|sum|subtract|minus|multiply|times|divide|x)\s+\d+(\s*(and|,)?\s*\d+)+", q):
        return True
    return False

def detect_mixed_task(question: str) -> bool:
    q = question.lower()
    # Mixed task = math + secondary keywords
    secondary_keywords = r"(and also|tell me|capital|translate|fun fact|tallest)"
    if detect_math_only(q) and re.search(secondary_keywords, q):
        return True
    return False

def call_llm(question: str) -> str:
    model = genai.GenerativeModel(MODEL)
    response = model.generate_content(
        SYSTEM_RULES + "\nUser: " + question
    )
    return response.text

def save_log(question: str, answer: str):
    # Ensure "level2" folder exists
    os.makedirs("level2", exist_ok=True)

    record = {
        "ts": datetime.utcnow().isoformat() + "Z",
        "question": question,
        "answer": answer
    }
    log_path = os.path.join("level2", "interactions_level2.log")
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")

def main():
    if len(sys.argv) < 2:
        print("Usage: python chatbot_with_tool.py \"Your question here\"")
        sys.exit(1)

    question = sys.argv[1]

    # Check for mixed task first
    if detect_mixed_task(question):
        answer = "I can’t do multi-step tasks yet (math + knowledge). Please ask one thing at a time."

    # Check for math only
    elif detect_math_only(question):
        answer = f"Answer: {calculate(question)}"

    # Otherwise → normal LLM
    else:
        answer = call_llm(question)

    # Print once
    print("\nAssistant:\n" + "="*40 + "\n" + answer + "\n" + "="*40 + "\n")

    # Save log in level2/interactions.log
    save_log(question, answer)

if __name__ == "__main__":
    main()


