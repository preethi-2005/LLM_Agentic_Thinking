# Level 1 – Easy: LLM-only Chatbot



A simple Python command-line assistant using **Gemini 1.5 Flash**.  
Focus: **Prompt engineering** to provide **step-by-step explanations** while **refusing direct arithmetic calculations** (Level 1 rule).



## Features

- Explains answers in **short numbered steps**.
- Provides a **friendly, structured response**.
- **Refuses arithmetic calculations**, hinting at Level 2 calculator tool.
- Logs all interactions in `interactions.log`.


## Requirements

- Python 3.10+
- [Gemini API Key](https://developers.generativeai.google/) stored in `.env` as `GEMINI_API_KEY`
- Install dependencies:

```bash
pip install -r requirements.txt


## Dependencies include:

- google-generativeai
- rich
- python-dotenv

## Usage

- CLI Mode

Ask a question directly:

python chatbot.py "What are the colors in a rainbow?"


## Interactive Mode
python chatbot.py


## Level 1 Rules

Always start responses with:
"Let's think step by step:"

Use 2–8 numbered steps.

End with a brief "Final answer:" summary.

Refuse arithmetic calculations (e.g., 15 + 23, 12 * 7), e.g.:

"I can’t calculate directly in Level 1. Hint: we’ll add a calculator tool in Level 2."


### Logs

- All interactions are saved in:

interactions.log


- Each entry contains:

Timestamp
Question
Assistant answer

###Example:
python level1/chatbot.py   "Which planet is the hottest?"

Assistant:
Answer:
Venus

Step-by-step reasoning:
1) While Mercury is closer to the Sun, Venus has a much thicker atmosphere.
2) This atmosphere is composed primarily of carbon dioxide, creating a runaway greenhouse effect.
3) The greenhouse effect traps heat, resulting in Venus having a surface temperature significantly higher than Mercury's.


###Example2:
python level1/chatbot.py  "What is 15 + 23?"                                                 
   
Assistant:
I can't solve direct arithmetic like 'What is 15 + 23?'.
Hint: Please use a calculator tool (phone, computer, or Python REPL).
