import os
import sys
import re
import json
from datetime import datetime
import google.generativeai as genai
from dotenv import load_dotenv 
load_dotenv()

# Configure Gemini
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
MODEL = "gemini-1.5-flash"

SYSTEM_RULES = (
    "You are a helpful tutor.\n"
    "Always reply in this exact format:\n"
    "Answer:\n"
    "<short answer here>\n\n"
    "Step-by-step reasoning:\n"
    "1) ...\n"
    "2) ...\n"
    "3) ..."
)

def is_basic_arithmetic(question: str) -> bool:
    # Look for simple arithmetic patterns anywhere in the string
    pattern = r"\b\d+\s*([+\-*/])\s*\d+\b"
    return re.search(pattern, question) is not None

def refuse_arithmetic(question: str) -> str:
    return (
        f"I can't solve direct arithmetic like '{question}'.\n"
        "Hint: Please use a calculator tool (phone, computer, or Python REPL)."
    )

def call_llm(question: str) -> str:
    model = genai.GenerativeModel(MODEL)
    response = model.generate_content(
        SYSTEM_RULES + "\nUser: " + question
    )
    return response.text

def save_log(question: str, answer: str):
    record = {
        "ts": datetime.utcnow().isoformat() + "Z",
        "question": question,
        "answer": answer
    }

    # Ensure log file goes inside this level1 folder
    log_dir = os.path.dirname(__file__)  
    log_file = os.path.join(log_dir, "interactions.log")

    with open(log_file, "a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")

def main():
    if len(sys.argv) < 2:
        print("Usage: python chatbot.py \"Your question here\"")
        sys.exit(1)

    question = sys.argv[1]

    if is_basic_arithmetic(question):
        answer = refuse_arithmetic(question)
    else:
        answer = call_llm(question)

    print("\nAssistant:\n" + answer + "\n")
    save_log(question, answer)

if __name__ == "__main__":
    main()
